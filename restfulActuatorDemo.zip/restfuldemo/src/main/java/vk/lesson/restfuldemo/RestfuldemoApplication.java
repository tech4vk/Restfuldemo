package vk.lesson.restfuldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfuldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfuldemoApplication.class, args);
	}

}
